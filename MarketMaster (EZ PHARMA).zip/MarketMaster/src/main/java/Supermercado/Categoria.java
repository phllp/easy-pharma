/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Supermercado;

/**
 *
 * @author carla
 */
public abstract class Categoria {

    protected String nome;

    public String getNome() {
        return nome;
    }

    public abstract float calcularLucro(int quant, float valor);

}
