/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Supermercado;

/**
 *
 * @author Ana
 */
public class FrutaseLegumes extends Categoria{

    public FrutaseLegumes() {
        this.nome = "Frutas e Legumes";
    }   
    @Override
    public float calcularLucro(int quant, float valor) {
        float percentualLucro = 0.200f; 
      
        if (quant >= 2 && quant < 5) {
           percentualLucro = 0.80f; 
        }else if(quant >= 5 ){
             percentualLucro = 0.70f; 
        }
        return valor * percentualLucro;
    }  
}
