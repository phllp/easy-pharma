/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Supermercado;

import java.util.ArrayList;

/**
 *
 * @author carla
 */
public class Cupom {

 
    private ArrayList<Produto> produtos;

    public Cupom() {
        this.produtos = new ArrayList<>();
    }

    public void adicionarProduto(Produto produto) {
        produtos.add(produto);
    }

    public String montarCupom() {
        String ler = "";
        for (int i = 0; i < produtos.size(); i++) {
            Produto produto = produtos.get(i);
            ler = ler + " -------------------------------MARKET MASTER-----------------------------------";
            ler = ler + "\n";
            ler = ler + "\n";
            ler = ler + " Produto: " + produto.getNome() + "   |";
            ler = ler + "    Preço unitário: " + "R$" + produto.getPreco() + "   |";
            ler = ler + "    Quantidade: " + produto.getQuantidade() + "   |";
            ler = ler + "\n";
            ler = ler + "\n";
        }

        return ler;
    }

    public String subTotal() {
        float valorTotal = 0f;
        for (int i = 0; i < produtos.size(); i++) {
            Produto produto = produtos.get(i);
            valorTotal += produto.getPreco() * produto.getQuantidade();
        }

        return " Valor Total: " + "R$ " + valorTotal;
    }

}
