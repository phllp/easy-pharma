/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Supermercado;

import java.io.IOException;

/**
 *
 * @author carla
 */
public class LoginUser {

    public static Usuario realizarLogin(Usuario usuario) throws IOException {
        PersistenciaArquivosUsuario dados = new PersistenciaArquivosUsuario();

        Usuario salvo = dados.consultar(usuario.getId());

        if (usuario.idAdm() == salvo.idAdm() && usuario.getSenha().equals(salvo.getSenha())) {
            return salvo;
        } else {
            return null;
        }

    }
}
