/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Supermercado;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.net.URISyntaxException;
import java.util.ArrayList;

/**
 *
 * @author carla
 */
public class PersistenciaArquivosUsuario {

    private FileWriter escritorArquivo;
    private FileReader leitorArquivo;
    private String caminhoArquivo;

    public PersistenciaArquivosUsuario() {
        this.caminhoArquivo = "../MarketMaster/dadosUsuario/dados.txt";        
    }

    private void novoEscritor(boolean estado) throws IOException {
        this.escritorArquivo = new FileWriter(this.caminhoArquivo, estado);//true: salvar no final do arquivo, false sobreescrever.
    }

    private void novoLeitor() throws IOException {
        this.leitorArquivo = new FileReader(caminhoArquivo);
    }

    public void salvar(Usuario usuario) throws IOException {
        // verificar: https://www.devmedia.com.br/leitura-e-escrita-de-arquivos-de-texto-em-java/25529
        this.novoEscritor(true);
        BufferedWriter buffWrite = new BufferedWriter(this.escritorArquivo);
        buffWrite.append(usuario.toString() + "\n");// adiciona elemento no final do arquivo
        buffWrite.close();
    }

    public void alterar(Usuario usuario) throws IOException {
        ArrayList<Usuario> listaUsuario = this.consultar();

        for (int i = 0; i < listaUsuario.size(); i++) {
            Usuario usu = listaUsuario.get(i);

            if (usu.getId() == usuario.getId()) {
                listaUsuario.remove(i);
                listaUsuario.add(usuario);
            }
        }
        novoEscritor(false);
        BufferedWriter buffWrite = new BufferedWriter(this.escritorArquivo);// CRIANDO ALGO QUE ESCREVE
        for (int i = 0; i < listaUsuario.size(); i++) {
            Usuario usu = listaUsuario.get(i);
            buffWrite.append(usu.toString() + "\n");// adiciona elemento no arquivo
        }

        buffWrite.close();
    }

    public ArrayList<Usuario> consultar() throws IOException {
        ArrayList<Usuario> listaUsuario = new ArrayList<>();
        this.novoLeitor();

        BufferedReader buffRead = new BufferedReader(this.leitorArquivo);
        String linha = buffRead.readLine();

        while (linha != null) {
            Usuario usuarioLeitura = Usuario.fromString(linha);
            listaUsuario.add(usuarioLeitura);
            linha = buffRead.readLine();
        }
        buffRead.close();
        return listaUsuario;
    }

    public Usuario consultar(int idUsario) throws IOException {
        ArrayList<Usuario> listaUsuario = this.consultar();

        for (int i = 0; i < listaUsuario.size(); i++) {
            Usuario usu = listaUsuario.get(i);

            if (usu.getId() == idUsario) {
                return usu;
            }
        }
        return null;
    }

    public void deletar(Usuario usuario) throws IOException {
        ArrayList<Usuario> listaUsuario = this.consultar();

        for (int i = 0; i < listaUsuario.size(); i++) {
            Usuario usu = listaUsuario.get(i);

            if (usu.getId() == usuario.getId()) {
                listaUsuario.remove(i);

            }
        }
        novoEscritor(false);
        BufferedWriter buffWrite = new BufferedWriter(this.escritorArquivo);// CRIANDO ALGO QUE ESCREVE
        for (int i = 0; i < listaUsuario.size(); i++) {
            Usuario usu = listaUsuario.get(i);
            buffWrite.append(usu.toString() + "\n");// adiciona elemento no arquivo
        }

        buffWrite.close();
    }

}
