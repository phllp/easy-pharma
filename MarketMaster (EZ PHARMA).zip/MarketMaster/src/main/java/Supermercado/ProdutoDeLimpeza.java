/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Supermercado;

/**
 *
 * @author carla
 */
public class ProdutoDeLimpeza extends Categoria {

    public ProdutoDeLimpeza() {
        this.nome = "Produto de Limpeza";
    }
        
    @Override
    public float calcularLucro(int quant, float valor) {
        float percentualLucro = 0.352f;
        if(quant >= 2){
            percentualLucro = 0.90f;
        }
        return valor * percentualLucro;
    }

}
