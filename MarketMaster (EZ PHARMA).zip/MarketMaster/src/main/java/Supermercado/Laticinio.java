/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Supermercado;

/**
 *
 * @author carla
 */
public class Laticinio extends Categoria {

    public Laticinio() {
        this.nome = "Laticínio";
    }

    @Override
    public float calcularLucro(int quant, float valor) {
        float percentualLucro = 0.400f;
        if (quant >= 3 && quant <5) {
            percentualLucro = 0.300f;
        }else if (quant >= 5 && quant < 10) {
            percentualLucro = 0.100f;
        }
        return valor * percentualLucro;
    }

}
