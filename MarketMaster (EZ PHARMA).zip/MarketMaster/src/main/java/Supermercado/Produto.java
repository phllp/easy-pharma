/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Supermercado;

/**
 *
 * @author carla
 */
public class Produto {

    private int id;
    private String nome;
    private float preco;
    private int quantidade;
    private Categoria categorias;

    public Produto(int id, String nome, float preco, int quantidade, Categoria categorias) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
        this.categorias = categorias;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public Object[] obterDados() {
        return new Object[]{this.id, this.nome, this.categorias.getNome(), this.preco, this.quantidade, this.categorias.calcularLucro(this.quantidade, this.preco)};
    }

    public Object[] obterDadosAreaVendas() {
        return new Object[]{this.id, this.nome, this.categorias.getNome(), this.preco, this.quantidade};
    }
}
