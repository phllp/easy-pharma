/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Supermercado;



/**
 *
 * @author carla
 */
public class Bebidas extends Categoria{

    public Bebidas() {
        this.nome = "Bebidas";
    }

    
    
    @Override
    public float calcularLucro(int quant, float valor) {
        float percentualLucro = 0.150f; 
      
        if (quant >= 12 && quant < 20) {
           percentualLucro = 0.90f; 
        }else if(quant >= 20 ){
             percentualLucro = 0.78f; 
        }
        return valor * percentualLucro;
    }

   
   
  
    
    
    
}
