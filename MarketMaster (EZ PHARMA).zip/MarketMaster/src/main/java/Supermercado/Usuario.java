/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Supermercado;

/**
 *
 * @author carla
 */
public class Usuario {

    private int id;
    private String nome;
    private String Senha;
    private boolean adm;

    public Usuario() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    }

    public boolean idAdm() {
        return adm;
    }

    public void setAdm(boolean adm) {
        this.adm = adm;
    }

    @Override
    public String toString() {
        return id + "," + nome + "," + Senha + "," + adm;
    }

    public static Usuario fromString(String dadosUsuario) {
        String[] dados = dadosUsuario.split(",");
        Usuario usuer = new Usuario();
        usuer.setId(Integer.parseInt(dados[0]));
        usuer.setNome(dados[1]);
        usuer.setSenha(dados[2]);

        if (dados[3].equals("true")) {
            usuer.setAdm(true);
        } else {
            usuer.setAdm(false);
        }
        return usuer;
    }
    
     public Object[] obterDados(){
        return new Object[] {this.id, this.nome, this.Senha};
    }

}
